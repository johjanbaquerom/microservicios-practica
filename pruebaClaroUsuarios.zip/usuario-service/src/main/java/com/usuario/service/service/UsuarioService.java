package com.usuario.service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usuario.service.entity.Usuario;
import com.usuario.service.repository.UsuarioRepository;

@Service
public class UsuarioService {

	@Autowired
	private UsuarioRepository usuarioRepository;
	
	public List<Usuario> getAll(){
		return usuarioRepository.findAll();
	}
	
	public Usuario getUsuarioById(int id) {
		return usuarioRepository.findById(id).orElse(null);
	}
	
	public Usuario save(Usuario usuario) {
		Usuario nuevoUsuario = usuarioRepository.save(usuario);
		return nuevoUsuario;
	}
	
	public Usuario updateUsuariosById(Usuario request, Integer id){
		Usuario nuevoUsuario = usuarioRepository.findById(id).get();
        nuevoUsuario.setNombre(request.getNombre());
        nuevoUsuario.setApellido(request.getApellido());
        nuevoUsuario.setEmail(request.getEmail());
        nuevoUsuario.setFechaRegistro(request.getFechaRegistro());
        return nuevoUsuario;
    }
	
	public boolean deleteUsuario(Integer id){
        try {
         usuarioRepository.deleteById(id);
         return true;
        }catch (Exception e){
            return false;
        }
    }
}
